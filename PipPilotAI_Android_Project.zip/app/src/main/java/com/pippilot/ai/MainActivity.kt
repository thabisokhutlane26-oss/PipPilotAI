package com.pippilot.ai

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(7,19,31)
    private val card = Color.rgb(13,31,47)
    private val green = Color.rgb(0,200,150)
    private var running = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun tv(text:String, size:Float, bold:Boolean=false): TextView {
        return TextView(this).apply {
            this.text=text; textSize=size; setTextColor(Color.WHITE)
            if(bold) typeface=Typeface.DEFAULT_BOLD
            setPadding(16,10,16,10)
        }
    }
    private fun cardText(text:String): TextView = tv(text,16f)

    private fun buildUi() {
        val scroll=ScrollView(this)
        val root=LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL; setPadding(18,18,18,24); setBackgroundColor(bg)
        }
        scroll.addView(root)

        root.addView(tv("PipPilot AI",28f,true))
        root.addView(tv("Automated Forex Trading • Demo Mode",14f))

        val status=tv("●  ROBOT STOPPED",16f,true)
        status.setTextColor(Color.rgb(255,180,80))
        root.addView(status)

        val balance=LinearLayout(this).apply {
            orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL
        }
        val bal=tv("Balance\n$10,000.00",20f,true)
        val pnl=tv("Today\n+$124.60",18f,true)
        balance.addView(bal,LinearLayout.LayoutParams(0,120,1f))
        balance.addView(pnl,LinearLayout.LayoutParams(0,120,1f))
        root.addView(balance)

        root.addView(tv("MARKET WATCH",14f,true))
        root.addView(cardText("EUR/USD     1.1718     ▲ 0.24%"))
        root.addView(cardText("GBP/USD     1.3512     ▲ 0.18%"))
        root.addView(cardText("XAU/USD     3,582.40   ▼ 0.31%"))

        root.addView(tv("ROBOT CONTROL",14f,true))
        val toggle=Switch(this).apply {
            text="Enable Demo Trading"; textSize=17f; setTextColor(Color.WHITE); isChecked=false
        }
        root.addView(toggle)
        toggle.setOnCheckedChangeListener { _, checked ->
            running=checked
            status.text=if(checked) "●  ROBOT RUNNING — DEMO" else "●  ROBOT STOPPED"
            status.setTextColor(if(checked) green else Color.rgb(255,180,80))
        }

        root.addView(tv("RISK SETTINGS",14f,true))
        val risk=SeekBar(this).apply { max=50; progress=10 }
        root.addView(tv("Risk per trade: 1.0%",16f))
        root.addView(risk)
        root.addView(tv("Daily loss limit: 3.0%\nMax open trades: 3\nStop Loss: 25 pips     Take Profit: 50 pips",15f))

        root.addView(tv("LATEST SIGNAL",14f,true))
        root.addView(cardText("EUR/USD  •  BUY\nConfidence: 78%  •  Demo only"))

        root.addView(tv("OPEN TRADES",14f,true))
        root.addView(cardText("No live trades. Demo mode is ready."))

        val note=tv("⚠ Trading involves substantial risk. This prototype does not guarantee profits. Real trading will require a supported broker/MT5 connection and explicit activation.",13f)
        note.setTextColor(Color.LTGRAY); root.addView(note)

        setContentView(scroll)
    }
}
