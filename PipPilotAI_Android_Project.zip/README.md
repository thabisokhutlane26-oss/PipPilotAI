# PipPilot AI
Android Forex-robot prototype, v1.0.

Features:
- Dashboard
- Demo robot ON/OFF
- Market watch
- Risk settings
- Demo signal
- Open-trade status
- Safety notice

This build does NOT place real-money trades. A broker/MT5 integration and trading backend must be added and tested before live execution.
